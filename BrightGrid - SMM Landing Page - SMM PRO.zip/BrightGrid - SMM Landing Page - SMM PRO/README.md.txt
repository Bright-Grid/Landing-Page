# BrightGrid - Responsive Electronics Store Landing Page

BrightGrid is a clean and modern landing page template designed for electronics stores. It is fully responsive, lightweight, and easy to customize.

## 🌐 Multilingual Support

BrightGrid includes **two language versions**:

- 🇺🇸 English (LTR)
- 🇸🇦 Arabic (RTL)

This makes it ideal for stores targeting both English and Arabic-speaking audiences.

## 🚀 Features

- Fully responsive design
- RTL & LTR layout support
- Clean and modern UI
- Font Awesome integration
- Dark/light mode toggle
- Language switcher
- Mobile-friendly navigation
- WhatsApp chat widget
- Secure payment section
- HTML5, CSS3, and JavaScript

## 📁 Files Included

- `index.html` (English version)
- `index-ar.html` (Arabic version)
- All assets embedded via CDN
- `README.md`
- `LICENSE` (MIT)

## 📦 Requirements

No external build tools needed. Just open the HTML file in your browser.

## 📜 License

This project is licensed under the MIT License – see the `LICENSE` file for details.

## 🛠️ Customization

You can easily update text, images, colors, or add integrations by editing the HTML content directly. All styling is included inline or through CDN-hosted libraries, making it simple to deploy.

## 💬 Support

For questions or customizations, feel free to contact us.

---

